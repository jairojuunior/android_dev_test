package br.edu.ufabc.padm.agendacontatos;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import br.edu.ufabc.padm.agendacontatos.model.Contato;
import br.edu.ufabc.padm.agendacontatos.model.ContatoDAO;


public class ContatoInsert extends AppCompatActivity {

    private ContatoDAO dao = ContatoDAO.newInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato_insert);
        registerHandlers();
    }

    private void registerHandlers() {
        Button saveButton = (Button)findViewById(R.id.insert_save_button);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleInsert();
            }
        });
    }

    private void handleInsert() {
        String nome = ((EditText )findViewById(R.id.insert_contato_nome)).getText().toString();
        String email = ((EditText )findViewById(R.id.insert_contato_email)).getText().toString();
        String endereco = ((EditText )findViewById(R.id.insert_contato_endereco)).getText().toString();
        String telefoneComercial = ((EditText )findViewById(R.id.insert_contato_telefone_comercial)).getText().toString();
        String telefoneResidencial = ((EditText )findViewById(R.id.insert_contato_telefone_residencial)).getText().toString();
        Contato contato = new Contato();

        contato.setNome(nome);
        contato.setEmail(email);
        contato.setEndereco(endereco);
        contato.setTelefoneComercial(telefoneComercial);
        contato.setTelefoneResidencial(telefoneResidencial);

        dao.add(contato);

        Toast.makeText(this, getString(R.string.insert_status_ok), Toast.LENGTH_SHORT).show();
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_contato_insert, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void insertContato(View view) {

    }
}
