package br.edu.ufabc.padm.intentdemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;


public class ImplicitIntentFilterTest extends AppCompatActivity {
    final int RESULT_CODE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_implicit_intent_filter_test);
        registerHandlers();
    }

    private void registerHandlers() {
        Button pickButton = (Button )findViewById(R.id.pick_button);
        final ImplicitIntentFilterTest self = this; // closure [Wikipedia: http://bit.ly/18PwJB4]

        pickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();

                intent.setAction(Intent.ACTION_PICK);
                intent.setType("text/contact"); // "invented" mime type

                if (intent.resolveActivity(getPackageManager()) != null)
                    startActivityForResult(intent, RESULT_CODE);
                else
                    Toast.makeText(self, getString(R.string.intent_unavailable_message),
                            Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0 && resultCode == RESULT_OK) {
            HashMap<String, String> contact = (HashMap<String, String> )data.getSerializableExtra("contact");
            TextView nome = (TextView)findViewById(R.id.contato_item_nome);
            TextView email = (TextView)findViewById(R.id.contato_item_email);
            TextView endereco = (TextView)findViewById(R.id.contato_item_endereco);
            TextView telComercial = (TextView)findViewById(R.id.contato_item_telcom);
            TextView telResidencial = (TextView)findViewById(R.id.contato_item_telres);
            TableLayout table = (TableLayout )findViewById(R.id.contact_show);

            nome.setText(contact.get("nome"));
            email.setText(contact.get("email"));
            endereco.setText(contact.get("endereco"));
            telComercial.setText(contact.get("telefoneComercial"));
            telResidencial.setText(contact.get("telefoneResidencial"));
            table.setVisibility(TableLayout.VISIBLE);
            Toast.makeText(this, getString(R.string.contact_success_message), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, getString(R.string.contact_failed_message), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_implicit_intent_filter_test, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
