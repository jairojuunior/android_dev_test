package br.edu.ufabc.padm.intentdemo;

import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class ExplicitIntentWithExtras extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explicit_intent_with_extras);
        setupHandlers();
    }

    private void setupHandlers() {
        Button sendButton = (Button )findViewById(R.id.intent_extra_send);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSend();
            }
        });
    }

    private void handleSend() {
        EditText nomeField = (EditText )findViewById(R.id.intent_extra_nome);
        EditText raField = (EditText )findViewById(R.id.intent_extra_ra);
        Intent intent = null;

        if (nomeField.getText().length() == 0)
            nomeField.setError(getString(R.string.empty_field));
        else if (raField.getText().length() == 0)
            raField.setError(getString(R.string.empty_field));
        else {
            intent = new Intent(this, ExplicitIntentWithExtrasTarget.class);
            intent.putExtra("nome", nomeField.getText().toString());
            intent.putExtra("ra", raField.getText().toString());
            startActivity(intent);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_explicit_intent_with_extras, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
