package br.edu.ufabc.padm.agendacontatos2.model;


import java.util.ArrayList;
import java.util.List;

public class ContatoDAO {
    private static ContatoDAO dao;
    private List<Contato> contatos;

    protected ContatoDAO() {}

    private void init() {
        contatos = new ArrayList<>();
        // TODO: remove when "insert" operation is implemented in the app
        loadTestData();
    }

    private void loadTestData() {
        Contato c;

        c = new Contato();

        c.setNome("Joao");
        c.setEmail("joao@email.com");
        c.setEndereco("Rua Apolinario");
        c.setTelefoneComercial("123445");
        c.setTelefoneResidencial("123458");

        contatos.add(c);

        c = new Contato();
        c.setNome("Maria");
        c.setEmail("maria@email.com");
        c.setEndereco("Rua Joana");
        c.setTelefoneComercial("123445");
        c.setTelefoneResidencial("123458");

        contatos.add(c);
    }

    public static ContatoDAO newInstance() {
        if (dao == null) {
            dao = new ContatoDAO();
            dao.init();
        }

        return dao;
    }

    public void add(Contato contato) {
        contatos.add(contato);
    }

    public boolean remove(int position) {
        boolean res = true;

        try {
            contatos.remove(position);
        } catch(IndexOutOfBoundsException e) {
            res = false;
        }

        return res;
    }

    public boolean removeAll(int[] positions) {
        Contato[] contatoObjects = new Contato[positions.length];
        boolean status = true;

        try {
            for (int i = 0; i < positions.length; i++)
                contatoObjects[i] = contatos.get(positions[i]);
            for (int i = 0; i < positions.length; i++)
                contatos.remove(contatoObjects[i]);
        } catch(IndexOutOfBoundsException e) {
            status = false;
        }

        return status;
    }

    public Contato[] list(Contato contato) {
        return contatos.toArray(new Contato[contatos.size()]);
    }

    public boolean update(int position, Contato contato) {
        boolean status = true;

        try {
            contatos.set(position, contato);
        } catch (IndexOutOfBoundsException e) {
            status = false;
        }

        return status;
    }

    public int size() {
        return contatos.size();
    }

    public Contato getItemAt(int pos) {
        return contatos.get(pos);
    }

}
