package br.edu.ufabc.padm.agendacontatos2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import br.edu.ufabc.padm.agendacontatos2.model.Contato;
import br.edu.ufabc.padm.agendacontatos2.model.ContatoDAO;


public class ContatoDetails extends AppCompatActivity {

    public static int CONTACT_EDIT_REQCODE = 0;

    int position;
    ContatoDAO dao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato_show);

        dao = ContatoDAO.newInstance();
        position = getIntent().getExtras().getInt("contactPosition");
        showContato();
    }

    private void showContato() {
        Contato contato = dao.getItemAt(position);

        ((TextView)findViewById(R.id.contato_item_nome)).setText(contato.getNome());
        ((TextView)findViewById(R.id.contato_item_endereco)).setText(contato.getEndereco());
        ((TextView)findViewById(R.id.contato_item_email)).setText(contato.getEmail());
        ((TextView)findViewById(R.id.contato_item_telcom)).setText(contato.getTelefoneComercial());
        ((TextView)findViewById(R.id.contato_item_telres)).setText(contato.getTelefoneResidencial());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CONTACT_EDIT_REQCODE && resultCode == RESULT_OK)
            showContato();
        else
            Toast.makeText(this, getString(R.string.edited_status_failed), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_contato_show, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_edit) {
            Intent intent = new Intent(this, ContatoInsertEdit.class);

            intent.putExtra("contactPosition", position);
            intent.putExtra("isEditing", true);

            startActivityForResult(intent, CONTACT_EDIT_REQCODE);
        }


        return super.onOptionsItemSelected(item);
    }
}
