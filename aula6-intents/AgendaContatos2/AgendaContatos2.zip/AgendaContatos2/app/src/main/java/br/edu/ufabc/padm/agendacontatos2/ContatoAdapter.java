package br.edu.ufabc.padm.agendacontatos2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import br.edu.ufabc.padm.agendacontatos2.model.Contato;
import br.edu.ufabc.padm.agendacontatos2.model.ContatoDAO;


public class ContatoAdapter extends BaseAdapter {
    private ContatoDAO dao;
    private Context context;

    public ContatoAdapter(Context c) {
        this.context = c;
        this.dao = ContatoDAO.newInstance();
    }

    public boolean remove(int position) {
        boolean status = dao.remove(position);

        if (status)
            this.notifyDataSetChanged(); // update the view

        return status;
    }

    public boolean removeAll(int[] positions) {
        boolean status = dao.removeAll(positions);
        if (status)
            this.notifyDataSetChanged(); // update the view

        return status;
    }

    public Contato getItemAt(int position) {
        return dao.getItemAt(position);
    }

    @Override
    public int getCount() {
        return dao.size();
    }

    @Override
    public Object getItem(int position) {
        return dao.getItemAt(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Contato contato = null;
        TextView nome = null;
        TextView email = null;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.contato_list_item, null);
        }
        contato = dao.getItemAt(position);
        nome = (TextView )convertView.findViewById(R.id.contact_name);
        email = (TextView )convertView.findViewById(R.id.contact_email);
        nome.setText(contato.getNome());
        email.setText(contato.getEmail());

        return convertView;
    }
}
