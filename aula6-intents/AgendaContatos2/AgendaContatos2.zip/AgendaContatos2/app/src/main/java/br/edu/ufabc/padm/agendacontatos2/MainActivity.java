package br.edu.ufabc.padm.agendacontatos2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import br.edu.ufabc.padm.agendacontatos2.model.Contato;
import br.edu.ufabc.padm.agendacontatos2.model.ContatoDAO;


public class MainActivity extends AppCompatActivity {
    private ContatoDAO dao;
    private ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        setupContatoList();
    }

    @Override
    protected void onResume() {
        super.onResume();

        ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
    }

    private void init() {
        this.dao = ContatoDAO.newInstance();
        listView = (ListView)findViewById(R.id.list_contatos);
    }


    private void setupContatoList() {
        listView = findViewById(R.id.list_contatos);
        final MainActivity self = this;

        listView.setAdapter(new ContatoAdapter(this));

        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        listView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                mode.setTitle(getString(R.string.context_menu_selected_count,
                        listView.getCheckedItemCount()));
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                MenuInflater inflater = mode.getMenuInflater();

                inflater.inflate(R.menu.menu_list_cab, menu);
                mode.setTitle(getResources().getString(R.string.context_menu_title));

                return true;
            }


            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            /**
             * Obtain positions of selected items and perform their removal in batch
             * @param mode
             * @param item
             * @return
             */
            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                SparseBooleanArray checkedContacts = listView.getCheckedItemPositions();
                ContatoAdapter contatoAdapter = (ContatoAdapter) listView.getAdapter();
                int id = item.getItemId();
                boolean status = false;

                if (id == R.id.action_context_remove) {
                    int[] removePositions = new int[checkedContacts.size()];
                    int j = 0;

                    for (int i = 0; i < contatoAdapter.getCount(); i++)
                        if (checkedContacts.get(i))
                            removePositions[j++] = i;
                    if (contatoAdapter.removeAll(removePositions)) {
                        mode.finish(); // close the CAB menu
                        Toast.makeText(self, getString(R.string.success_remove_contact),
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(self, getString(R.string.failed_remove_contact),
                                Toast.LENGTH_LONG).show();
                    }
                    status = true;
                } else {
                    Log.e("MenuDemo", "Unknown operation");
                    status = true;
                }

                return status;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = null;
                ContatoAdapter contatoAdapter = (ContatoAdapter) listView.getAdapter();

                intent = new Intent(parent.getContext(), ContatoDetails.class);
                intent.putExtra("contactPosition", position);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_add) {
            Intent intent = new Intent(this, ContatoInsertEdit.class);

            intent.putExtra("isEditing", false);
            startActivity(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
