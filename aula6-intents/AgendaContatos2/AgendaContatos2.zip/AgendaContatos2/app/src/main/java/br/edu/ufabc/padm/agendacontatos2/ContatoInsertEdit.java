package br.edu.ufabc.padm.agendacontatos2;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import br.edu.ufabc.padm.agendacontatos2.model.Contato;
import br.edu.ufabc.padm.agendacontatos2.model.ContatoDAO;


public class ContatoInsertEdit extends AppCompatActivity {

    private ContatoDAO dao = ContatoDAO.newInstance();
    private ContatoForm contatoForm;
    private boolean isEditing;

    public class ContatoForm {
        EditText nome;
        EditText email;
        EditText endereco;
        EditText telefoneComercial;
        EditText telefoneResidencial;

        ContatoForm() {
            nome = findViewById(R.id.insert_contato_nome);
            email = findViewById(R.id.insert_contato_email);
            endereco = findViewById(R.id.insert_contato_endereco);
            telefoneComercial = findViewById(R.id.insert_contato_telefone_comercial);
            telefoneResidencial = findViewById(R.id.insert_contato_telefone_residencial);
        }

        public String getNome() {
            return nome.getText().toString().trim();
        }

        public String getEmail() {
            return email.getText().toString().trim();
        }

        public String getEndereco() {
            return endereco.getText().toString().trim();
        }

        public String getTelefoneComercial() {
            return telefoneComercial.getText().toString().trim();
        }

        public String getTelefoneResidencial() {
            return telefoneResidencial.getText().toString().trim();
        }

        public boolean isValid() {
            boolean isValid = true;

            if (getNome().isEmpty()) {
                isValid = false;
                nome.setError(getString(R.string.required_field));
            }
            if (getEmail().isEmpty()) {
                isValid = false;
                email.setError(getString(R.string.required_field));
            }
            if (getEndereco().isEmpty()) {
                isValid = false;
                endereco.setError(getString(R.string.required_field));
            }

            return isValid;
        }

        public void fill(Contato contato) {
            nome.setText(contato.getNome());
            email.setText(contato.getEmail());
            endereco.setText(contato.getEndereco());
            telefoneComercial.setText(contato.getTelefoneComercial());
            telefoneResidencial.setText(contato.getTelefoneResidencial());
        }

        public Contato toContato() {
            Contato contato = new Contato();

            contato.setNome(getNome());
            contato.setEmail(getEmail());
            contato.setEndereco(getEndereco());
            contato.setTelefoneResidencial(getTelefoneResidencial());
            contato.setTelefoneComercial(getTelefoneComercial());

            return contato;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato_insert);
        contatoForm = new ContatoForm();
    }

    @Override
    protected void onStart() {
        super.onStart();

        isEditing = getIntent().getExtras().getBoolean("isEditing");

        if (isEditing) {
            setTitle(R.string.title_activity_contato_edit);
            fillForm();
        } else
            setTitle(R.string.title_activity_contato_insert);
    }

    private void handleInsert() {
        if (contatoForm.isValid()) {
            dao.add(contatoForm.toContato());

            Toast.makeText(this, getString(R.string.insert_status_ok), Toast.LENGTH_SHORT).show();
            finish();
        } else
            Toast.makeText(this, getString(R.string.insert_status_error), Toast.LENGTH_SHORT).show();
    }

    private void fillForm() {
        int position = getIntent().getExtras().getInt("contactPosition");
        Contato contato = dao.getItemAt(position);

        contatoForm.fill(contato);
    }

    private void handleEdit() {
        if (contatoForm.isValid()) {
            int position = getIntent().getExtras().getInt("contactPosition");

            dao.update(position, contatoForm.toContato());
            Toast.makeText(this, getString(R.string.edit_status_ok), Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else
            Toast.makeText(this, getString(R.string.insert_status_error), Toast.LENGTH_SHORT).show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_contato_insert, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.action_save)
            if (isEditing)
                handleEdit();
            else
                handleInsert();


        return super.onOptionsItemSelected(item);
    }
}
