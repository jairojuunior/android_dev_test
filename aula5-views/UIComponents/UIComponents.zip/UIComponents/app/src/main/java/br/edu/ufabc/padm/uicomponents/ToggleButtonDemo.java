package br.edu.ufabc.padm.uicomponents;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;


public class ToggleButtonDemo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toggle_button_demo);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_toggle_button_demo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void handleToggle(View view) {
        int id = view.getId();
        boolean on = ((ToggleButton)view).isChecked();

        if (id == R.id.popup_notification)
            ((Switch )findViewById(R.id.switch_popup_notification)).setChecked(on);
        else if (id == R.id.email_notification)
            ((Switch )findViewById(R.id.switch_email_notification)).setChecked(on);
        else if (id == R.id.sms_notification)
            ((Switch )findViewById(R.id.switch_sms_notification)).setChecked(on);

    }

    public void handleSwitch(View view) {
        int id = view.getId();
        boolean on = ((Switch)view).isChecked();

        if (id == R.id.switch_popup_notification)
            ((ToggleButton )findViewById(R.id.popup_notification)).setChecked(on);
        else if (id == R.id.switch_email_notification)
            ((ToggleButton )findViewById(R.id.email_notification)).setChecked(on);
        else if (id == R.id.switch_sms_notification)
            ((ToggleButton )findViewById(R.id.sms_notification)).setChecked(on);
    }
}
