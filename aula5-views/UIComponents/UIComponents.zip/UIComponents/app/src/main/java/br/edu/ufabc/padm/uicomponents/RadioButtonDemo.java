package br.edu.ufabc.padm.uicomponents;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RadioButtonDemo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_button_demo);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_radio_button_demo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void radioButtonClickHandler(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        int id = view.getId();
        String message = "You are ";

        if (id == R.id.option_professor)
            message += " a Professor";
        else if (id == R.id.option_ta)
            message += " a Teaching Assistant";
        else if (id == R.id.option_grad)
            message += " a Graduate Student";
        else if (id == R.id.option_undergrad)
            message += " a Undergrad student";
        else
            message = "Your role is unknown";

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
