package br.edu.ufabc.padm.uicomponents;

import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MenuDemo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_demo);
        setUpListView();
    }

    private void setUpListView() {
        // retrieve the list layout
        final ListView listView = (ListView )findViewById(R.id.cities_list);

        // register the adapter
        listView.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_activated_1,
                getResources().getStringArray(R.array.cities_list)));

        // register the contextual menu
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        listView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                mode.setTitle(getString(R.string.context_menu_selected_count,
                        listView.getCheckedItemCount()));
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                MenuInflater inflater = mode.getMenuInflater();

                inflater.inflate(R.menu.menu_context_demo, menu);
                mode.setTitle(getResources().getString(R.string.context_menu_title));

                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                int count = listView.getCheckedItemCount();

                switch (item.getItemId()) {
                    case R.id.action_context_remove:
                        Toast.makeText(listView.getContext(), getString(R.string.status_context_add, count),
                                Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_context_share:
                        Toast.makeText(listView.getContext(), getString(R.string.status_context_share, count),
                                Toast.LENGTH_SHORT).show();
                    default:
                        Log.e("MenuDemo", "Unknown operation");
                }

                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu_demo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
