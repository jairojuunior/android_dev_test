package br.edu.ufabc.padm.uicomponents;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;


public class UIComponentsDemo extends AppCompatActivity {

    class ComponentChoiceListener implements AdapterView.OnItemSelectedListener {
        private Context context;

        public ComponentChoiceListener(Context c) {
            this.context = c;
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String choice = parent.getItemAtPosition(position).toString();
            Intent intent = null;

            switch (choice) {
                case "Button":
                    intent = new Intent(context, ButtonDemo.class);
                    break;
                case "Text field":
                    intent = new Intent(context, EditTextDemo.class);
                    break;
                case "Checkbox":
                    intent = new Intent(context, CheckboxDemo.class);
                    break;
                case "Radio button":
                    intent = new Intent(context, RadioButtonDemo.class);
                    break;
                case "Toggle button":
                    intent = new Intent(context, ToggleButtonDemo.class);
                    break;
                case "Spinner":
                    intent = new Intent(context, SpinnerDemo.class);
                    break;
                case "Action bar":
                    intent = new Intent(context, ActionBarDemo.class);
                    break;
                case "Menu":
                    intent = new Intent(context, MenuDemo.class);
                    break;

                case "Button theme":
                    intent = new Intent(context, ButtonStyleDemo.class);
                    break;
            }

            if (intent != null)
                startActivity(intent);
            else
                Log.w("UIComponentsDemo", "No option has been selected");
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            Log.d("TESTING", "no item has been selected");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uicomponents_demo);
        populateComponentChooser();
    }

    private void populateComponentChooser() {
        Spinner componentChooser = (Spinner )findViewById(R.id.component_chooser);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.component_choices,
                android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        componentChooser.setAdapter(adapter);
        componentChooser.setOnItemSelectedListener(new ComponentChoiceListener(this));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_uicomponents_demo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }
}
